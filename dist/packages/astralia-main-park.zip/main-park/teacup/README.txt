瓷梦茶会 · THE PORCELAIN TEA PARTY

青花瓷杯与中央巨壶。双击 index.html 即可运行；也可作为任意静态站点部署。
操作：选择茶杯，拖动或按 A/D 转动杯盘。
