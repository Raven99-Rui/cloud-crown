星梦奇境 · 主园

这是主园的完整单文件构建，包含 11 项设施；旁边的 balloon/rainbow/pirate/teacup 是四个独立体验入口。

请把本文件夹作为网站根目录提供（不要直接双击 index.html）；例如：
  python -m http.server 8080
然后打开 http://127.0.0.1:8080/。
