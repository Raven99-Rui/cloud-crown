彩虹滑道机 · THE RAINBOW CHUTE

六条琉璃滑道。双击 index.html 即可运行；也可部署为任意静态站点。
操作：选择颜色，沿楼梯登顶后滑下。
